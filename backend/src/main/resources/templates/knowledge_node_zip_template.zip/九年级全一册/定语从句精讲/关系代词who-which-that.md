## 关系代词用法

| 关系代词 | 先行词 | 在从句中充当 | 例句 |
|---------|--------|------------|------|
| who | 人 | 主语/宾语 | The girl who is singing is my sister. |
| whom | 人 | 宾语 | The man whom you met is my teacher. |
| which | 物 | 主语/宾语 | The book which I read was interesting. |
| that | 人/物 | 主语/宾语 | This is the best film that I have ever seen. |

## 只能用 that 的情况
1. 先行词被最高级修饰
2. 先行词被序数词修饰
3. 先行词是 all, everything, nothing 等不定代词
4. 先行词既有人又有物

## 只能用 which 的情况
1. 非限制性定语从句
2. 介词后：The house in which I live
