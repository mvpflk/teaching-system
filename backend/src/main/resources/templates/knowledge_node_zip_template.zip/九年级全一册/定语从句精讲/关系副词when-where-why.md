## 关系副词

| 关系副词 | 先行词 | 在从句中充当 | 例句 |
|---------|--------|------------|------|
| when | 时间名词 | 时间状语 | I'll never forget the day when we met. |
| where | 地点名词 | 地点状语 | This is the school where I studied. |
| why | reason | 原因状语 | That's the reason why he was late. |

## 关系副词 = 介词 + which
- when = on/in/during which
- where = in/at which
- why = for which

## 典型例题
This is the factory ___ I worked last year.
→ where / in which
