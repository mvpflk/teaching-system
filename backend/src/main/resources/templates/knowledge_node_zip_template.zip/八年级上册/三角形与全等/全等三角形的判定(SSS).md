## SSS判定定理
三边对应相等的两个三角形全等。

## 符号语言
在△ABC和△DEF中，
∵ AB = DE，BC = EF，AC = DF
∴ △ABC ≌ △DEF (SSS)

## 典型例题
已知：如图，AB = CD，BC = DA
求证：△ABC ≌ △CDA

## 注意事项
1. 必须严格按对应顺序书写
2. "SSS"表示三边判定法的英文缩写
